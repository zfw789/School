// CalculatorApp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <fstream>
#include <stack>
#include <vector>
#include <algorithm>
using namespace std;

int OpPrecedence(char op) {
	if (op == '+' || op == '-')
		return 1;
	if (op == '*' || op == '/' || op == '%')
		return 2;
	if (op == '^')
		return 3;
	return 0;
}

int doOperation(int a, int b, char op) {
	switch (op) {
	case '+': return a + b;
	case '-': return a - b;
	case '*': return a * b;
	case '/': return a / b;
	case '%': return a % b;
	case '^': return pow(a, b);
	}
}

int Calculate(string expression) {
	if (expression == "exit")
	{
		return 0;
	}
	int i;

	stack<int> numstack;
	stack<char> opstack;
	string ops = "+-*/^%";

	for (i = 0; i < expression.length(); i++)
	{
		if (expression[i] == '(') {
			opstack.push(expression[i]);
		}
		else if (isdigit(expression[i])) {
			int value = 0;

			while (i < expression.length() && isdigit(expression[i])) {
				value = (value * 10) + (expression[i] - '0');
				i++;
			}

			numstack.push(value);
		}
		else if (expression[i] == ')') {
			while (!opstack.empty() && opstack.top() != '(')
			{
				int num1 = numstack.top();
				numstack.pop();

				int num2 = numstack.top();
				numstack.pop();

				char op = opstack.top();
				opstack.pop();

				numstack.push(doOperation(num2, num1, op));
			}
			opstack.pop();
		}
		else if (ops.find(expression[i]) != ops.npos)
		{
			while (!opstack.empty() && (OpPrecedence(opstack.top()) >= OpPrecedence(expression[i])))
			{
				int num1 = numstack.top();
				numstack.pop();

				int num2 = numstack.top();
				numstack.pop();

				char op = opstack.top();
				opstack.pop();

				numstack.push(doOperation(num2, num1, op));
			}
			opstack.push(expression[i]);
		}
	}

	while (!opstack.empty())
	{
		int num1 = numstack.top();
		numstack.pop();

		int num2 = numstack.top();
		numstack.pop();

		char op = opstack.top();
		opstack.pop();

		numstack.push(doOperation(num2, num1, op));
	}

	return numstack.top();
}

int main()
{
	ofstream file;
	string expression;
	vector<string> expHist = { "", "", "", "", "", "", "", "", "", "" };
	cout << "Enter 'exit' to exit \n";

	while (expression != "exit")
	{
		getline(cin, expression);
		expHist.push_back(expression);

		file.open("ExpressionHist.txt");
		for (auto it = expHist.begin(); it != expHist.end(); ++it)
		{
			if (*it != "" && *it != "exit")
			{
				file << *it << "\n";
			}
			
		}
		file.close();

		cout << Calculate(expression) << "\n";
	}
	
}
